package jfront;

import java.awt.TextArea;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Hashtable;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public /*static*/ class M
{
	public static void main(String[] args)
	{
		String fileData = readFile("../Complex.jf");
		TextFile out = new TextFile("jfront/Complex.java");
		List opdefs = new ArrayList();
		M.pass1(fileData, out, opdefs);
		M.pass2(fileData, out, opdefs);
	}
	
	private static String readFile(String filename)
	{
		StringBuilder ret = new StringBuilder();
		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(M.class.getResourceAsStream(filename), "UTF-8"));
			//specifically, the file is expected to be encoded in UTF-8 with or without BOM
			
			while (true)
			{
				String line = reader.readLine();
				if (line == null)
					break;
				ret.append(line);
				ret.append("\r\n");
			}
			if (ret.length() >= 2)
				ret.setLength(ret.length() - 2);

			reader.close();
		}
		catch (java.net.MalformedURLException e) {e.printStackTrace();}
		catch (IOException e) {e.printStackTrace();}
		return ret.toString();
	}

	public static void pass1(String file, TextFile out, List opdefs)
	{
		StreamToken st = new StreamToken(new StringStream(file));
		st.nextToken();
		String className = "";
		String innerClassName = "";
		int j = 0, l = 0;
		while (st.ttype != -1)
		{
			if (st.ttype == 10 || st.ttype == 4)
				{st.nextToken(); continue;}
			if (st.ttype == -2)
				S.p(st.nval);
			else if (st.ttype == -3)
			{
				if (st.sval.equals("class"))
				{
					st.nextToken();
					if (st.ttype != -3)
						continue;
					if (l <= j)
					{
						className = st.sval;
						j = l;
						innerClassName = "";
					}
					else if (l == j + 1)
						innerClassName = st.sval;
				}

				if (st.sval.equals("operator"))
				{
					st.nextToken();
					if (st.ttype != -5)
						continue;

					Opdef opd = new Opdef();
					opd.op = st.sval;
					opd.classname = className;
					opd.innername = innerClassName;
					opd.oPname = Opers.name(st.sval);
					opdefs.add(opd);
				}
			}
			else
			{
				if ((int)(char)st.ttype == 123)
					++l;
				if ((int)(char)st.ttype == 125)
				{
					--l;
					if (l <= j + 1)
						innerClassName = "";

				}
			}
			st.nextToken();
		}
	}

	public static void pass2(String file, TextFile out, List opdefs)
	{
		Hashtable class_ops = new Hashtable();
		Hashtable class_wops = new Hashtable();

		{
			ListIterator opdefIter = opdefs.listIterator();
			while (opdefIter.hasNext())
			{
				Opdef opdef = (Opdef)opdefIter.next();

				String str4 = opdef.classname;
				String str5 = opdef.classname + ":" + opdef.op;
				if (!opdef.innername.equals(""))
				{
					str5 = opdef.innername + ":" + opdef.op;
					str4 = opdef.innername;
				}
				class_ops.put(str5, "operator" + opdef.oPname);
				if (class_wops.containsKey(str4))
					continue;
				class_wops.put(str4, str4);
			}
		}

		StreamToken st = new StreamToken(new StringStream(file));
		st.nextToken();
		List l = new ArrayList();
		Hashtable class_vars = new Hashtable();
		int i = 0, j = -1, k = 0;
		while (st.ttype != -1)
		{
			boolean cont = false;
			if (st.ttype == 10)
			{
				l.add(new Lntoken(10, "\n"));
				j = 10;
			}
			else if (st.ttype == -2)
			{
				l.add(new Lntoken(-2, " " + Double.toString(st.nval)));
				j = -2;
			}
			else if (st.ttype == -3)
			{
				if ((st.sval.equals("import")) || (st.sval.equals("class")))
				{
					String sval = st.sval;
					l.add(new Lntoken(-3, " " + st.sval));
					j = -3;
					st.nextToken();
					if (st.ttype != -3) continue;
					if (sval.equals("class") && k <= i)
						i = k;
				}

				if (st.sval.equals("operator"))
				{
					st.nextToken();
					if (st.ttype != -5)
						continue;
					st.sval = ("operator" + Opers.name(st.sval));
				}

				if (class_wops.containsKey(st.sval))
				{
					l.add(new Lntoken(-3, " " + st.sval));
					j = -3;

					String sval = st.sval;

					st.nextToken();
					while (true)
					{
						if (st.ttype != -3 || st.sval.equals("operator")) {cont = true; break;}//break label;
						class_vars.put(st.sval, sval);
						l.add(new Lntoken(-3, " " + st.sval));

						j = -3;
						st.nextToken();
						if (st.ttype != 44) {cont = true; break;}//break label;
						l.add(new Lntoken(-6, new Character((char)st.ttype).toString()));
						j = -6;
						st.nextToken();
					}
					if (cont)
						if (st.ttype != -1)
							continue;
						else
							break;
				}

				if (j == -3) out.write(" ");

				if (j == -3) st.sval = (" " + st.sval);
				l.add(new Lntoken(-3, st.sval));
				j = -3;
			}
			else if (st.ttype == -4)
			{
				j = -4;
				l.add(new Lntoken(-4, st.sval));
			}
			else if (st.ttype == -5)
			{
				l.add(new Lntoken(-5, st.sval));
				j = -5;
			}
			else
			{
				char c = (char)st.ttype;
				if (c == '"' || c == '\'')
					l.add(new Lntoken(-6, c + st.sval + c));
				else
				{
					l.add(new Lntoken(-6, String.valueOf(c)));
					if (c == '{') ++k;
					if (c == '}') --k;
					if (c == ';')
					{
						analyze(out, l, class_vars, class_ops);
						while (l.size() > 0) l.remove(0);
					}
				}
				j = -6;
			}

			label: st.nextToken();
		}

		analyze(out, l, class_vars, class_ops);

		while (l.size() > 0) l.remove(0);
		
		out.close();
	}

	private static void analyze(TextFile out, List list, Hashtable ht, Hashtable class_ops)
	{
		int i = 0;
		String str1 = "";
		int k = 0;
		Object localObject1 = " ";
		Object localObject2 = "";
		List listO3;
		int i4;
		for (int j = 0; j == 0;)
		{
			j = 1;
			listO3 = new ArrayList();
			i = 0;
			int i2 = 0;

			int l = 0;
			ListIterator listIter = list.listIterator();
			Lntoken localLntoken;
			Paren localParen;
			int i1;
			while (listIter.hasNext())
			{
				localLntoken = (Lntoken)listIter.next();

				if (localLntoken.token.equals("("))
				{
					l = list.indexOf(localLntoken);
					listO3.add(i2, new Paren(l, -1, "", i));
					++i;
					++i2;
				}
				
				if (l != 0 && list.indexOf(localLntoken) == l + 1 && localLntoken.type == -3)
				{
					localParen = (Paren)listO3.get(i2 - 1);
					localParen.token = localLntoken.token;
					listO3.set(i2 - 1, localParen);
				}

				if (localLntoken.token.equals(")"))
				{
					--i;
					if (i < 0)
					{
						out.write("\n// JFront Error: The following statement has too many close Paren')'s \n");
						break;
					}
					i1 = list.indexOf(localLntoken);
					for (int i3 = i2 - 1; i3 >= 0; --i3)
					{
						localParen = (Paren)listO3.get(i3);
						if (localParen.token.length() != 0) localObject1 = localParen.token;
						if (localParen.after < 0)
						{
							localParen.after = i1;
							if (localParen.token.length() == 0) localParen.token = ((String)localObject1);
							listO3.set(i3, localParen);
							break;
						}
					}
				}
			}
			if (i > 0)
				out.write("\n// JFront Error: The following statement has unbalenced Paren'()'s \n");

			i4 = 99;
			localObject1 = " ";
			localObject2 = " ";
			int i5 = 0;
			int i6 = 0;
			i2 = 0;
			listIter = list.listIterator();
			k = 0;
			if (i == 0)
			{
				while (listIter.hasNext())
				{
					localLntoken = (Lntoken)listIter.next();
					if (localLntoken.token.equals("("))
						{++i; ++i2;}
					if (localLntoken.token.equals(")"))
						--i;
					if (k != 0 && localLntoken.type == -5)
					{
						String str2 = (String)ht.get(str1);
						localObject1 = str2 + ":" + localLntoken.token;
						if (class_ops.containsKey(localObject1))
						{
							int i7 = Opers.priority(localLntoken.token);

							if (i > i5 || (i == i5 && i7 < i4))
							{
								i4 = i7;
								i5 = i;
								i6 = list.indexOf(localLntoken);
								localObject2 = localObject1;
								j = 0;
							}
						}
					}

					k = 0;
					str1 = "";

					if (localLntoken.type == -3)
					{
						if (!ht.containsKey(localLntoken.token))
							continue;
						k = 1;
						str1 = localLntoken.token;
					}
					else if (localLntoken.token.equals(")"))
					{
						localParen = (Paren)listO3.get(i2 - 1);
						if (!ht.containsKey(localParen.token))
							continue;
						k = 1;
						str1 = localParen.token;
					}
				}

				if (j != 0)
					continue;
				localObject1 = localObject2;
				String str2 = (String)class_ops.get(localObject1);

				i1 = i6 + 2;
				l = i6 - 1;
				if (list.size() > i6 + 1)
				{
					localLntoken = (Lntoken)list.get(i6 + 1);

					if (localLntoken.token.equals("("))
					{
						localParen = (Paren)listO3.get(i2 - 1);
						i1 = localParen.after;
					}

					localLntoken = (Lntoken)list.get(i6 - 1);

					if (localLntoken.token.equals(")"))
					{
						for (int i3 = 0; i3 < i2 - 1; --i3)
						{
							localParen = (Paren)listO3.get(i3);
							if (localParen.after == i6 - 1)
							{
								l = localParen.before;
								break;
							}
						}
					}
				}

				list.add(i1, new Lntoken(-6, ")"));
				list.add(i1, new Lntoken(-6, ")"));
				list.add(i6 + 1, new Lntoken(-6, "("));
				list.set(i6, new Lntoken(-5, str2));
				list.add(i6, new Lntoken(-6, "."));
				list.add(l, new Lntoken(-6, "("));
			}
		}

		int bracelev = 0;
		for (Object token : list)
		{
			String tokenO3 = ((Lntoken)token).token;
			if (tokenO3.equals("{")) bracelev++;
			if (tokenO3.equals("}")) bracelev--;

			out.write(tokenO3);
			if (tokenO3.substring(tokenO3.length() - 1).equals("\n"))
			for (i4 = 0; i4 < bracelev; ++i4)
				out.write(" ");
		}
	}
}

class Lntoken
{
	public final int type;
	public final String token;

	public Lntoken(int type, String token)
	{
		this.type = type;
		this.token = token;
	}
}

class Paren
{
	public int before;
	public int after;
	public String token;
	public int level;

	public Paren(int before, int after, String token, int level)
	{
		this.before = before;
		this.after = after;
		this.token = token;
		this.level = level;
	}
}

class Opdef
{
	public String op;
	public String classname;
	public String innername;
	public String oPname;
}

class StringStream
{
	private final char[] buf;
	private int ptr = -1;

	public StringStream(String ins) {buf = ins.toCharArray();}

	public int read()
	{
		ptr++;
		return ptr < buf.length? buf[ptr] : -1;
	}
}