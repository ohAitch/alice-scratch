package jfront;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Component;
import java.awt.Container;
import java.awt.Event;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextComponent;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;

public class JFrontApplet extends Applet
{
	private TextArea in = new TextArea(50, 80);
		{in.setFont(new Font("Courier", 0, 14));}
	private TextArea out = new TextArea(50, 80);
		{out.setFont(new Font("Courier", 0, 14)); out.setEditable(false);}
	private Button go = new Button("Run jfront");
	private Button load = new Button("load sample file");
	private Button clr = new Button("clear");

	public void init()
	{
		Panel buttons = new Panel();
		buttons.add(go);
		buttons.add(load);
		buttons.add(clr);

		GridBagLayout gbl = new GridBagLayout();
		super.setLayout(gbl);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.fill = 2;
		gbc.weighty = 0.0;
		gbc.weightx = 1.0;
		super.add(buttons);
		gbl.setConstraints(buttons, gbc);

		super.add(in);
		Label l1 = new Label(" Input File: (.jf) -- paste your source in here");
		super.add(l1);
		gbc.gridy = 1;
		gbl.setConstraints(l1, gbc);
		Label l2 = new Label(" Result File: (.java)");
		super.add(out);
		super.add(l2);
		gbc.gridy = 3;
		gbl.setConstraints(l2, gbc);

		gbc.gridy = 2;
		gbc.fill = 1;
		gbc.weighty = 0.5;
		gbl.setConstraints(in, gbc);
		gbc.gridy = 4;
		gbl.setConstraints(out, gbc);
		super.validate();
		super.show();
	}

	public boolean action(Event ev, Object unusedParam)
	{
		if (ev.target.equals(this.go))
		{
			this.out.setText("");
			this.out.appendText("// converted by jfront 0.43. Copyright (c) G&G Inc \n");

			M.pass(this.in.getText(), new StringReceiver(this.out));
		}
		else if (ev.target.equals(this.load))
		{
			this.out.setText("");
			this.in.setText("");
			this.in.appendText(readFileURLfromApplet("Complex.jf"));
		}
		else if (ev.target.equals(this.clr))
		{
			this.out.setText("");
			this.in.setText("");
		}
		else
		{
			S.pln("Action ? " + ev);
			return false;
		}
		return true;
	}

	private String readFileURLfromApplet(String file)
	{
		StringBuilder ret = new StringBuilder();
		DataInputStream dis = null;
		try {dis = new DataInputStream(new BufferedInputStream(new URL(super.getDocumentBase(), file).openStream()));}
		catch (MalformedURLException e) {S.pln("MalformedURLException "); return ret.toString();}
		catch (Exception e) {S.pln("Unexpected exception: " + e); return ret.toString();}

		String str = " ";
		try {str = dis.readLine();}
		catch (Exception e) {S.pln("Unexpected exception: " + e); return ret.toString();}
		while (true)
		{
			ret.append(str + "\n");
			try {str = dis.readLine();}
			catch (Exception e) {S.pln("Unexpected exception: " + e); break;}
			if (str == null) break;
		}
		
		return ret.toString();
	}
}