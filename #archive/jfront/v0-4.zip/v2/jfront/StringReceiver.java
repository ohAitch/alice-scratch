package jfront;

import java.awt.TextArea;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.FileNotFoundException;

public class StringReceiver
{
	private static final short TA = 0x4e13;
	private static final short BW = 0x45a1;
	private static final short NA = 0x197c;
	private short mode = NA;
	private TextArea ta = null;
	private BufferedWriter bw = null;
	
	public StringReceiver(TextArea ta)
	{
		this.ta = ta;
		mode = TA;
	}
	
	public StringReceiver(String filename)
	{
		try
		{
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Complex.java"), "UTF-8"));
			mode = BW;
		}
		catch (FileNotFoundException e) {mode = NA;}
		catch (UnsupportedEncodingException e) {mode = NA;}
	}
	
	public void append(String s)
	{
		switch (mode)
		{
			case TA: ta.append(s); break;
			case BW:
				try {bw.write(s);}
				catch (IOException e) {close();}
				break;
			default: throw new IllegalStateException();
		}
	}
	
	public void close()
	{
		switch (mode)
		{
			case TA: mode = NA; break;
			case BW:
				try {bw.close();}
				catch (IOException e) {}
				mode = NA;
				break;
			default: throw new IllegalStateException();
		}
	}
}