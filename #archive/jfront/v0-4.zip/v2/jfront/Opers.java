package jfront;

import java.util.Hashtable;

public class Opers
{
	private static final Hashtable ops = new Hashtable();
	private static Pn pnrtn;
	private static String last = "";

	static {
		ops.put("!", new Pn(0, "not"));
		ops.put("~", new Pn(0, "tilde"));
		ops.put("++", new Pn(0, "incr"));
		ops.put("--", new Pn(0, "decr"));

		ops.put("*", new Pn(1, "mult"));
		ops.put("/", new Pn(1, "div"));
		ops.put("%", new Pn(1, "pct"));

		ops.put("+", new Pn(2, "plus"));
		ops.put("-", new Pn(2, "minus"));

		ops.put("<<", new Pn(3, "2lt"));
		ops.put(">>", new Pn(3, "2gt"));
		ops.put(">>>", new Pn(3, "3gt"));

		ops.put("<", new Pn(4, "lt"));
		ops.put("<=", new Pn(4, "lteq"));
		ops.put(">", new Pn(4, "gt"));
		ops.put(">=", new Pn(4, "gteq"));

		ops.put("==", new Pn(5, "eqeq"));
		ops.put("!=", new Pn(5, "noteq"));

		ops.put("&", new Pn(6, "and"));
		ops.put("^", new Pn(7, "caret"));
		ops.put("|", new Pn(8, "or"));
		ops.put("&&", new Pn(9, "2and"));
		ops.put("||", new Pn(10, "2or"));

		ops.put("=", new Pn(11, "assign"));
		ops.put("*=", new Pn(11, "stareq"));
		ops.put("/=", new Pn(11, "slaseq"));
		ops.put("+=", new Pn(11, "pluseq"));
		ops.put("-=", new Pn(11, "minueq"));
		ops.put("%=", new Pn(11, "pcteq"));
		ops.put("<<=", new Pn(11, "2lteq"));
		ops.put(">>=", new Pn(11, "2gteq"));
		ops.put(">>>=", new Pn(11, "3gteq"));
		ops.put("&=", new Pn(11, "andeq"));
		ops.put("^=", new Pn(11, "careq"));
		ops.put("|=", new Pn(11, "oreq"));
	}

	public static boolean look(String s)
	{
		boolean bool = ops.containsKey(s);
		if (bool)
			pnrtn = (Pn)ops.get(s);
		else
			pnrtn = new Pn(0, "");
		last = s;
		return bool;
	}

	public static int priority(String s)
	{
		if (s.equals(last))
			return pnrtn.level;
		look(s);
		return pnrtn.level;
	}

	public static String name(String s)
	{
		if (s.equals(last))
			return pnrtn.name;
		look(s);
		return pnrtn.name;
	}
	
	private static class Pn
	{
		public final int level;
		public final String name;

		public Pn(int level, String name) {this.level = level; this.name = name;}
	}
}