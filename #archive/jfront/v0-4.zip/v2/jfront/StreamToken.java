package jfront;

import java.io.IOException;
import java.io.InputStream;

public class StreamToken
{
	private StringStream input;
	private char[] buf = new char[20];
	private int peekc;
	private boolean pushedBack;
	private boolean forceLower;
	private int LINENO = 1;
	private String opstr = "";

	private boolean eolIsSignificantP = false;
	private boolean slashSlashCommentsP = false;
	private boolean slashStarCommentsP = false;
	private boolean commentAsAlphaP = false;
	private boolean parseOps = false;

	private byte[] ctype = new byte[256];
	private static final byte CT_WHITESPACE = 1;
	private static final byte CT_DIGIT = 2;
	private static final byte CT_ALPHA = 4;
	private static final byte CT_QUOTE = 8;
	private static final byte CT_COMMENT = 16;
	public int ttype = -6;
	public static final int TT_EOF = -1;
	public static final int TT_EOL = 10;
	public static final int TT_NUMBER = -2;
	public static final int TT_WORD = -3;
	public static final int TT_COMMENT = -4;
	public static final int TT_OPER = -5;
	public static final int TT_NOTHING = -6;
	public String sval;
	public double nval;
	private boolean iscomment;

	/*private StreamToken()
	{
		wordChars(97, 122);
		wordChars(65, 90);
		wordChars(160, 255);
		whitespaceChars(0, 32);
		commentChar(47);
		quoteChar(34);
		quoteChar(39);

		iscomment = false;
		ttype = -6;
	}*/
	
	public StreamToken(StringStream input)
	{
		if (input == null) throw new IllegalArgumentException();
		this.input = input;
		eolIsSignificant(true);
		ordinaryChars(0, 255);
		wordChars(97, 122);
		wordChars(65, 90);
		wordChars(48, 57);
		wordChars(160, 255);
		whitespaceChars(0, 32);
		commentChar(47);
		quoteChar(34);
		quoteChar(39);
		wordChar(46);
		wordChar(95);
		wordChar(92);
		commentAsAlpha(true);
		parseOperators(true);
	}

	public void resetSyntax()
	{
		for (int i = ctype.length; --i >= 0; )
			ctype[i] = 0;
	}

	public void wordChars(int i1, int i2)
	{
		if (i1 < 0)
			i1 = 0;
		if (i2 >= ctype.length)
			i2 = ctype.length - 1;
		while (i1 <= i2)
		{
			int i = i1++;
			ctype[i] = (byte)(ctype[i] | 0x4);
		}
	}
	public void wordChar(int i) {if (i >= 0 && i < ctype.length) ctype[i] = (byte)(ctype[i] | 0x4);}
	public void whitespaceChars(int i1, int i2)
	{
		if (i1 < 0)
			i1 = 0;
		if (i2 >= ctype.length)
			i2 = ctype.length - 1;
		while (i1 <= i2)
			ctype[i1++] = 1;
	}
	public void ordinaryChars(int i1, int i2)
	{
		if (i1 < 0)
			i1 = 0;
		if (i2 >= ctype.length)
			i2 = ctype.length - 1;
		while (i1 <= i2)
			ctype[i1++] = 0;
	}
	public void ordinaryChar(int i) {if (i >= 0 && i < ctype.length) ctype[i] = 0;}
	public void commentChar(int i) {if (i >= 0 && i < ctype.length) ctype[i] = 16;}
	public void quoteChar(int i) {if (i >= 0 && i < ctype.length) ctype[i] = 8;}

	public void parseNumbers()
	{
		for (int i = 48; i <= 57; ++i)
			ctype[i] = (byte)(ctype[i] | 0x2);
		ctype[46] = (byte)(ctype[46] | 0x2);
		ctype[45] = (byte)(ctype[45] | 0x2);
	}

	public void eolIsSignificant(boolean b) {eolIsSignificantP = b;}
	public void slashStarComments(boolean b) {slashStarCommentsP = b;}
	public void slashSlashComments(boolean b) {slashSlashCommentsP = b;}
	public void commentAsAlpha(boolean b) {if (b) ctype[47] = 16; commentAsAlphaP = b;}
	public void lowerCaseMode(boolean b) {forceLower = b;}
	public void parseOperators(boolean b) {parseOps = b;}
	
	public void pushBack() {if (ttype != -6) pushedBack = true;}
	public int lineno() {return LINENO;}

	public int nextToken()
	{
		if (pushedBack)
		{
			pushedBack = false;
			return ttype;
		}

		sval = null;
		opstr = "";
		int i;
		if (ttype == -6)
		{
			i = input.read();
			if (i >= 0)
				ttype = i;
		}
		else
			i = peekc;

		if (i < 0)
			return ttype = -1;

		int j = i < 256? ctype[i] : 4;

		while ((j & 0x1) != 0)
		{
			if (i == 13)
			{
				LINENO++;
				i = input.read();
				if (i == 10)
					i = input.read();
				if (eolIsSignificantP)
				{
					peekc = i;
					return ttype = 10;
				}
			}
			else
			{
				if (i == 10)
				{
					LINENO++;
					if (eolIsSignificantP)
					{
						peekc = input.read();
						return ttype = 10;
					}
				}
				i = input.read();
			}
			if (i < 0)
				return ttype = -1;
			j = (i < 256) ? ctype[i] : 4;
		}
		
		if ((commentAsAlphaP && (j & 0x10) != 0) || iscomment)
		{
			int k = 1;
			buf[0] = (char)i;

			peekc = input.read();
			if (iscomment || peekc == 42 || peekc == 47)
			{
				i = peekc;
				while (i != 10 && i != 13 && i >= 0)
				{
					if (k == 1 && i == 42)
						iscomment = true;

					if (k >= buf.length)
					{
						char[] arr = new char[buf.length * 2];
						S.ac(buf, 0, arr, 0, buf.length);
						buf = arr;
					}
					buf[k++] = (char)i;

					if (iscomment && (char)i == '/' && buf[k - 2] == '*')
					{
						iscomment = false;
						i = input.read();
						break;
					}
					i = input.read();
				}
				sval = String.copyValueOf(buf, 0, k);
				peekc = i;
				return ttype = -4;
			}
		}

		if ((j & 0x2) != 0)
		{
			int k = 0;
			if (i == 45)
			{
				i = input.read();
				if (i != 46 && (i < 48 || i > 57))
				{
					peekc = i;
					return ttype = 45;
				}
				k = 1;
			}
			double d1 = 0.0;
			int i1 = 0;
			int i2 = 0;
			while (true)
			{
				if (i == 46 && i2 == 0)
					i2 = 1;
				else
				{
					if (i < 48 || i > 57) break;
					d1 = d1 * 10 + (i - 48);
					i1 += i2;
				}

				i = input.read();
			}
			peekc = i;
			if (i1 != 0)
			{
				double d2 = 10;
				--i1;
				while (i1 > 0)
				{
					d2 *= 10;
					--i1;
				}

				d1 /= d2;
			}
			nval = (k == 0? d1 : -d1);
			return ttype = -2;
		}
		
		if ((j & 0x4) != 0)
		{
			int k = 0;
			do
			{
				if (k >= buf.length)
				{
					char[] arr = new char[buf.length * 2];
					S.ac(buf, 0, arr, 0, buf.length);
					buf = arr;
				}
				buf[k++] = (char)i;
				i = input.read();
				j = (i < 256) ? ctype[i] : (i < 0) ? 1 : 4;
			} while ((j & 0x6) != 0);
			peekc = i;
			sval = String.copyValueOf(buf, 0, k);
			if (forceLower)
				sval = sval.toLowerCase();
			return ttype = -3;
		}

		if ((j & 0x8) != 0)
		{
			ttype = i;
			int k = 0;

			peekc = input.read();
			while (peekc >= 0 && peekc != ttype && peekc != 10 && peekc != 13)
			{
				i = peekc;
				peekc = input.read();

				if (k >= buf.length)
				{
					char[] arr = new char[buf.length * 2];
					S.ac(buf, 0, arr, 0, buf.length);
					buf = arr;
				}
				buf[k++] = (char)i;
			}
			if (peekc == ttype)
				peekc = input.read();
			sval = String.copyValueOf(buf, 0, k);
			return ttype;
		}

		if (i == 47 && (slashSlashCommentsP || slashStarCommentsP))
		{
			i = input.read();
			if (i == 42 && slashStarCommentsP)
			{
				int k = 0;
				while ((i = input.read()) != 47 || k != 42)
				{
					if (i == 13)
					{
						LINENO++;
						i = input.read();
						if (i == 10)
							i = input.read();
					}
					else if (i == 10)
					{
						LINENO++;
						i = input.read();
					}

					if (i < 0)
						return ttype = -1;
					k = i;
				}
				peekc = input.read();
				return nextToken();
			}
			if ((i == 47) && (slashSlashCommentsP))
			{
				while ((i = input.read()) != 10 && i != 13 && i >= 0);
				peekc = i;
				return nextToken();
			}
			peekc = i;
			return ttype = 47;
		}

		if (parseOps)
		{
			if (commentAsAlphaP && (char)i != '/')
				peekc = input.read();

			opstr = String.valueOf((char)i);

			boolean b = Opers.look(opstr);
			if (!b)
			{
				ttype = i;
				i = peekc;
				return ttype;
			}

			for (int l = 0; l < 3; ++l)
			{
				opstr += String.valueOf((char)peekc);
				b = Opers.look(opstr);
				if (!b)
				{
					sval = opstr.substring(0, opstr.length() - 1);
					return ttype = -5;
				}
				peekc = input.read();
			}
			sval = opstr;

			return ttype = -5;
		}

		return ttype = i;
	}

	/*public String toString()
	{
		String str;
		switch (ttype)
		{
			case -1: str = "EOF"; break;
			case 10: str = "EOL"; break;
			case -3: str = sval; break;
			case -2: str = "n=" + nval; break;
			case -6: str = "NOTHING"; break;
			default:
				char[] arr = new char[3];
				arr[2] = 39; arr[0] = 39;
				arr[1] = (char)ttype;
				str = new String(arr);
		}

		return "Token[" + str + "], line " + LINENO;
	}*/
}