package jfront;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Vector;

public class Pass1
{
	String file;
	Vector Opdefs;

	public Pass1(String paramString, Vector paramVector, boolean paramBoolean)
	{
		this.file = paramString;
		this.Opdefs = paramVector;
		Object localObject;
		if (paramBoolean)
		{
			localObject = new StringInputStream(this.file);
			try
			{
				Pass1Data((InputStream)localObject);

				return;
			}
			catch (IOException localIOException2)
			{
				System.out.println("Could not open string as file" + 
					localIOException2.getMessage());

				return;
			}

		}

		try
		{
			localObject = new FileInputStream(this.file);
			BufferedInputStream localBufferedInputStream = new BufferedInputStream((InputStream)localObject);
			DataInputStream localDataInputStream = new DataInputStream(localBufferedInputStream);
			Pass1Data(localDataInputStream);
			localDataInputStream.close();
			localBufferedInputStream.close();
			((FileInputStream)localObject).close();

			return;
		}
		catch (IOException localIOException1)
		{
			System.out.println("Could not open file " + this.file + ": " + 
				localIOException1.getMessage());
		}
	}

	void Pass1Data(InputStream paramInputStream)
		throws IOException
	{
		String str1 = "";
		int j = 0;
		String str2 = "";
		String str3 = "";
		Opers localOpers = new Opers();

		StreamToken localStreamToken = new StreamToken(paramInputStream);
		localStreamToken.eolIsSignificant(true);
		localStreamToken.ordinaryChars(0, 255);
		localStreamToken.wordChars(97, 122);
		localStreamToken.wordChars(65, 90);
		localStreamToken.wordChars(48, 57);
		localStreamToken.wordChars(160, 255);
		localStreamToken.whitespaceChars(0, 32);
		localStreamToken.commentChar(47);
		localStreamToken.quoteChar(34);
		localStreamToken.quoteChar(39);
		localStreamToken.wordChar(46);
		localStreamToken.wordChar(95);
		localStreamToken.wordChar(92);
		localStreamToken.commentAsAlpha(true);
		localStreamToken.parseOperators(true);
		localStreamToken.nextToken();

		int k = -1;

		int l = 0;
		while (localStreamToken.ttype != -1)
		{
			if (localStreamToken.ttype == 10)
			{
				k = 10;
			}
			else if (localStreamToken.ttype == -2)
			{
				System.out.print(localStreamToken.nval);
				k = -2;
			}
			else if (localStreamToken.ttype == -3)
			{
				if (localStreamToken.sval.equals("class"))
				{
					localStreamToken.nextToken();
					if (localStreamToken.ttype != -3) continue;
					if (l <= j) {
						str1 = localStreamToken.sval;
						j = l;
						str2 = "";
					} else if (l == j + 1) {
						str2 = localStreamToken.sval;
					}

				}

				if (localStreamToken.sval.equals("operator"))
				{
					localStreamToken.nextToken();
					if (localStreamToken.ttype != -5)
						continue;
					str3 = localStreamToken.sval;
					String str4 = localOpers.name(str3);

					Opdef localOpdef = new Opdef();
					localOpdef.op = str3;
					localOpdef.classname = str1;
					localOpdef.innername = str2;
					localOpdef.oPname = str4;
					this.Opdefs.addElement(localOpdef);
				}

				k = -3;
			}
			else if (localStreamToken.ttype == -4)
			{
				k = -4;
			}
			else
			{
				int i = (char)localStreamToken.ttype;
				if ((i != 34) && (i != 39))
				{
					if (i == 123) ++l;
					if (i == 125) {
						--l;
						if (l <= j + 1) {
							str2 = "";
						}

					}

				}

				k = -6;
			}
			localStreamToken.nextToken();
		}
	}
}