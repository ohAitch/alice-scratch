package jfront;

public class Lntoken
{
	int type;
	String token;
	String othertoken;

	Lntoken(int paramInt, String paramString)
	{
		this.type = paramInt;
		this.token = paramString;
		this.othertoken = "";
	}
}