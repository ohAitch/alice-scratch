package jfront;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Component;
import java.awt.Container;
import java.awt.Event;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextComponent;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

public class JFrontApplet extends Applet
{
	Panel buttons;
	TextArea in;
	TextArea out;
	Button go;
	Button load;
	Button clr;

	public String getAppletInfo()
	{
		return "JFront v 0.43- Copyright (c) 1998, Garnatz and Grovender, Inc. ";
	}

	public void init()
	{
		this.buttons = new Panel();
		this.in = new TextArea(50, 80);
		this.out = new TextArea(50, 80);
		this.in.setFont(new Font("Courier", 0, 14));
		this.out.setFont(new Font("Courier", 0, 14));
		this.out.setEditable(false);

		this.go = new Button("Run jfront");
		this.load = new Button("load sample file");
		this.clr = new Button("clear");
		this.buttons.add(this.go);
		this.buttons.add(this.load);
		this.buttons.add(this.clr);

		GridBagLayout localGridBagLayout = new GridBagLayout();
		super.setLayout(localGridBagLayout);
		GridBagConstraints localGridBagConstraints = new GridBagConstraints();
		localGridBagConstraints.gridx = 0;
		localGridBagConstraints.fill = 2;
		localGridBagConstraints.weighty = 0.0D;
		localGridBagConstraints.weightx = 1.0D;
		super.add(this.buttons);
		localGridBagLayout.setConstraints(this.buttons, localGridBagConstraints);

		super.add(this.in);
		Label localLabel1 = new Label(" Input File: (.jf) -- paste your source in here");
		super.add(localLabel1);
		localGridBagConstraints.gridy = 1;
		localGridBagLayout.setConstraints(localLabel1, localGridBagConstraints);
		Label localLabel2 = new Label(" Result File: (.java)");
		super.add(this.out);
		super.add(localLabel2);
		localGridBagConstraints.gridy = 3;
		localGridBagLayout.setConstraints(localLabel2, localGridBagConstraints);

		localGridBagConstraints.gridy = 2;
		localGridBagConstraints.fill = 1;
		localGridBagConstraints.weighty = 0.5D;
		localGridBagLayout.setConstraints(this.in, localGridBagConstraints);
		localGridBagConstraints.gridy = 4;
		localGridBagLayout.setConstraints(this.out, localGridBagConstraints);
		super.validate();
		super.show();
	}

	public boolean action(Event paramEvent, Object paramObject)
	{
		Object localObject = paramEvent.target;
		if (localObject.equals(this.go)) {
			this.out.setText("");
			this.out.appendText("// converted by jfront 0.43. Copyright (c) G&G Inc \n");

			Vector localVector = new Vector();
			String str = this.in.getText();
			new Pass1(str, localVector, true);

			new Pass2(str, localVector, true, this.out);

			return true;
		}if (localObject.equals(this.load)) {
			this.out.setText("");
			this.in.setText("");
			this.in.appendText(new String(ReadFileURL("Complex.jf")));
			return true;
		}if (localObject.equals(this.clr)) {
			this.out.setText("");
			this.in.setText("");
			return true;
		}
		System.out.println("Action ? " + paramEvent);
		return false;
	}

	public StringBuffer ReadFileURL(String paramString)
	{
		StringBuffer localStringBuffer = new StringBuffer();
		int i = 0;
		InputStream localInputStream = null;
		DataInputStream localDataInputStream = null;
		URL localURL = null;
		try
		{
			localURL = new URL(super.getDocumentBase(), paramString);
		}
		catch (MalformedURLException localMalformedURLException) {
			System.out.println("MalformedURLException ");

			return localStringBuffer;
		}
		try
		{
			localInputStream = localURL.openStream();
			localDataInputStream = new DataInputStream(new BufferedInputStream(localInputStream));
		}
		catch (Exception localException1) {
			System.out.println("Unexpected exception: " + localException1);

			return localStringBuffer;
		}

		String str = " ";
		try {
			str = localDataInputStream.readLine();
		}
		catch (Exception localException2) {
			System.out.println("Unexpected exception: " + localException2);
			i = 1;
		}

		while (i == 0) {
			localStringBuffer.append(str + "\n");
			try
			{
				str = localDataInputStream.readLine();
			}
			catch (Exception localException3) {
				System.out.println("Unexpected exception: " + localException3);
				i = 1;
			}
			if (str == null) {
				i = 1;
			}

		}

		return localStringBuffer;
	}
}