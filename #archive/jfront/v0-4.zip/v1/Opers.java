package jfront;

import java.util.Hashtable;

public class Opers
{
	Hashtable ops = new Hashtable();
	Pn Pnrtn;
	String last = "";
	Pn dummy = new Pn(0, "");

	public Opers()
	{
		this.ops.put("!", new Pn(0, "not"));
		this.ops.put("~", new Pn(0, "tilde"));
		this.ops.put("++", new Pn(0, "incr"));
		this.ops.put("--", new Pn(0, "decr"));

		this.ops.put("*", new Pn(1, "mult"));
		this.ops.put("/", new Pn(1, "div"));
		this.ops.put("%", new Pn(1, "pct"));

		this.ops.put("+", new Pn(2, "plus"));
		this.ops.put("-", new Pn(2, "minus"));

		this.ops.put("<<", new Pn(3, "2lt"));
		this.ops.put(">>", new Pn(3, "2gt"));
		this.ops.put(">>>", new Pn(3, "3gt"));

		this.ops.put("<", new Pn(4, "lt"));
		this.ops.put("<=", new Pn(4, "lteq"));
		this.ops.put(">", new Pn(4, "gt"));
		this.ops.put(">=", new Pn(4, "gteq"));

		this.ops.put("==", new Pn(5, "eqeq"));
		this.ops.put("!=", new Pn(5, "noteq"));

		this.ops.put("&", new Pn(6, "and"));
		this.ops.put("^", new Pn(7, "caret"));
		this.ops.put("|", new Pn(8, "or"));
		this.ops.put("&&", new Pn(9, "2and"));
		this.ops.put("||", new Pn(10, "2or"));

		this.ops.put("=", new Pn(11, "assign"));
		this.ops.put("*=", new Pn(11, "stareq"));
		this.ops.put("/=", new Pn(11, "slaseq"));
		this.ops.put("+=", new Pn(11, "pluseq"));
		this.ops.put("-=", new Pn(11, "minueq"));
		this.ops.put("%=", new Pn(11, "pcteq"));
		this.ops.put("<<=", new Pn(11, "2lteq"));
		this.ops.put(">>=", new Pn(11, "2gteq"));
		this.ops.put(">>>=", new Pn(11, "3gteq"));
		this.ops.put("&=", new Pn(11, "andeq"));
		this.ops.put("^=", new Pn(11, "careq"));
		this.ops.put("|=", new Pn(11, "oreq"));
	}

	public boolean look(String paramString) {
		boolean bool = this.ops.containsKey(paramString);
		if (bool)
			this.Pnrtn = ((Pn)this.ops.get(paramString));
		else {
			this.Pnrtn = this.dummy;
		}
		this.last = paramString;
		return bool;
	}

	public int priority(String paramString) {
		if (paramString.equals(this.last)) {
			return this.Pnrtn.level;
		}
		look(paramString);
		return this.Pnrtn.level;
	}

	public String name(String paramString) {
		if (paramString.equals(this.last)) {
			return this.Pnrtn.name;
		}
		look(paramString);
		return this.Pnrtn.name;
	}
}