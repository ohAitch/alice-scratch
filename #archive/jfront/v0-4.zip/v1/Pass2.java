package jfront;

import java.awt.TextArea;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Pass2
{
	String file;
	Vector Opdefs;
	Hashtable class_ops;
	Hashtable class_wops;
	Hashtable class_vars;
	static int bracelev;

	Pass2(String paramString, Vector paramVector, boolean paramBoolean, TextArea paramTextArea)
	{
		this.file = paramString;
		this.Opdefs = paramVector;
		Object localObject;
		if (paramBoolean)
		{
			localObject = new StringInputStream(this.file);
			try
			{
				Pass2Data((InputStream)localObject, paramTextArea);

				return;
			}
			catch (IOException localIOException2)
			{
				System.out.println("Could not open string as file" + 
					localIOException2.getMessage());

				return;
			}

		}

		try
		{
			localObject = new FileInputStream(this.file);
			BufferedInputStream localBufferedInputStream = new BufferedInputStream((InputStream)localObject);
			DataInputStream localDataInputStream = new DataInputStream(localBufferedInputStream);
			Pass2Data(localDataInputStream, System.out);
			localDataInputStream.close();
			localBufferedInputStream.close();
			((FileInputStream)localObject).close();

			return;
		}
		catch (IOException localIOException1)
		{
			System.out.println("Could not open file " + this.file + ": " + 
				localIOException1.getMessage());
		}
	}

	void Pass2Data(InputStream paramInputStream, Object paramObject)
		throws IOException
	{
		String str1 = "";
		int i = 0;
		String str2 = "";
		String str3 = "";
		Opers localOpers = new Opers();

		this.class_ops = new Hashtable();
		this.class_wops = new Hashtable();
		this.class_vars = new Hashtable();

		Vector localVector = new Vector();

		StreamToken localStreamToken = new StreamToken(paramInputStream);
		localStreamToken.eolIsSignificant(true);
		localStreamToken.ordinaryChars(0, 255);
		localStreamToken.wordChars(97, 122);
		localStreamToken.wordChars(65, 90);
		localStreamToken.wordChars(48, 57);
		localStreamToken.wordChars(160, 255);
		localStreamToken.whitespaceChars(0, 32);
		localStreamToken.commentChar(47);
		localStreamToken.quoteChar(34);
		localStreamToken.quoteChar(39);
		localStreamToken.wordChar(46);
		localStreamToken.wordChar(95);
		localStreamToken.wordChar(92);
		localStreamToken.commentAsAlpha(true);
		localStreamToken.parseOperators(true);
		localStreamToken.nextToken();

		int j = -1;
		int k = 0;

		Enumeration localEnumeration = this.Opdefs.elements();
		Opdef localOpdef = new Opdef();
		String str4;
		while (localEnumeration.hasMoreElements()) {
			localOpdef = (Opdef)localEnumeration.nextElement();

			str4 = localOpdef.classname;
			String str5 = localOpdef.classname + ":" + localOpdef.op;
			if (!localOpdef.innername.equals("")) {
				str5 = localOpdef.innername + ":" + localOpdef.op;
				str4 = localOpdef.innername;
			}
			this.class_ops.put(str5, "operator" + localOpdef.oPname);
			if (this.class_wops.containsKey(str4)) continue; this.class_wops.put(str4, str4);
		}

		while (localStreamToken.ttype != -1)
		{
		boolean cont = false;
			if (localStreamToken.ttype == 10)
			{
				localVector.addElement(new Lntoken(10, "\n"));
				j = 10;
			}
			else if (localStreamToken.ttype == -2)
			{
				localVector.addElement(new Lntoken(-2, " " + Double.toString(localStreamToken.nval)));
				j = -2;
			}
			else if (localStreamToken.ttype == -3)
			{
				if ((localStreamToken.sval.equals("import")) || (localStreamToken.sval.equals("class")))
				{
					str4 = localStreamToken.sval;
					localVector.addElement(new Lntoken(-3, " " + localStreamToken.sval));
					j = -3;
					localStreamToken.nextToken();
					if (localStreamToken.ttype != -3) continue;
					if (str4.equals("class"))
					{
						if (k <= i)
						{
							str1 = localStreamToken.sval;
							i = k;
							str2 = "";
						}
						else if (k == i + 1)
							str2 = localStreamToken.sval;
					}
				}

				if (localStreamToken.sval.equals("operator"))
				{
					localStreamToken.nextToken();
					if (localStreamToken.ttype != -5)
						continue;
					str3 = localStreamToken.sval;
					str4 = localOpers.name(str3);
					localStreamToken.sval = ("operator" + str4);
				}

				if (this.class_wops.containsKey(localStreamToken.sval))
				{
					localVector.addElement(new Lntoken(-3, " " + localStreamToken.sval));
					j = -3;

					str4 = localStreamToken.sval;

					localStreamToken.nextToken();
					while (true)
					{
						if (localStreamToken.ttype != -3 || localStreamToken.sval.equals("operator")) {cont = true; break;}//break label;
						this.class_vars.put(localStreamToken.sval, str4);
						localVector.addElement(new Lntoken(-3, " " + localStreamToken.sval));

						j = -3;
						localStreamToken.nextToken();
						if (localStreamToken.ttype != 44) {cont = true; break;}//break label;
						localVector.addElement(new Lntoken(-6, new Character((char)localStreamToken.ttype).toString()));
						j = -6;
						localStreamToken.nextToken();
					}
					if (cont)
						if (localStreamToken.ttype != -1)
							continue;
						else
							break;
				}

				if (j == -3) print(paramObject, " ");

				if (j == -3) localStreamToken.sval = (" " + localStreamToken.sval);
				localVector.addElement(new Lntoken(-3, localStreamToken.sval));
				j = -3;
			}
			else if (localStreamToken.ttype == -4)
			{
				j = -4;
				localVector.addElement(new Lntoken(-4, localStreamToken.sval));
			}
			else if (localStreamToken.ttype == -5)
			{
				localVector.addElement(new Lntoken(-5, localStreamToken.sval));
				j = -5;
			}
			else
			{
				char c = (char)localStreamToken.ttype;
				if (c == '"' || c == '\'')
					localVector.addElement(new Lntoken(-6, c + localStreamToken.sval + c));
				else
				{
					localVector.addElement(new Lntoken(-6, new Character(c).toString()));
					if (c == '{') ++k;
					if (c == '}') --k;
					if (c == ';')
					{
						analyze(paramObject, localVector, this.class_vars, localOpers);
						localVector.removeAllElements();
					}
				}
				j = -6;
			}

			label: localStreamToken.nextToken();
		}

		analyze(paramObject, localVector, this.class_vars, localOpers);

		localVector.removeAllElements();
	}

	void print(Object paramObject, String paramString)
	{
		if (paramObject instanceof TextArea) {
			Object localObject = (TextArea)paramObject;
			((TextArea)localObject).appendText(paramString);

			return;
		}

		Object localObject = (PrintStream)paramObject;
		((PrintStream)localObject).print(paramString);
	}

	void analyze(Object paramObject, Vector paramVector, Hashtable paramHashtable, Opers paramOpers)
	{
		int i = 0;
		Enumeration localEnumeration = paramVector.elements();

		int j = 0;
		String str1 = "";
		int k = 0;
		Object localObject1 = " ";
		Object localObject2 = "";
		Object localObject3;
		int i4;
		while (j == 0) {
			j = 1;
			localObject3 = new Vector();
			i = 0;
			int i2 = 0;

			int l = 0;
			localEnumeration = paramVector.elements();
			Lntoken localLntoken;
			int i3;
			Paren localParen;
			int i1;
			while (localEnumeration.hasMoreElements()) {
				localLntoken = (Lntoken)localEnumeration.nextElement();

				if (localLntoken.token.equals("(")) {
					l = paramVector.indexOf(localLntoken);
					((Vector)localObject3).insertElementAt(new Paren(l, -1, "", i), i2);
					++i;
					++i2;
				}
				if (l != 0) {
					i3 = paramVector.indexOf(localLntoken);
					if ((i3 == l + 1) && 
						(localLntoken.type == -3)) {
						localParen = (Paren)((Vector)localObject3).elementAt(i2 - 1);
						localParen.token = localLntoken.token;
						((Vector)localObject3).setElementAt(localParen, i2 - 1);
					}

				}

				if (localLntoken.token.equals(")")) {
					--i;
					if (i < 0) {
						print(paramObject, "\n// JFront Error: The following statement has too many close Paren')'s \n");
						break;
					}
					i1 = paramVector.indexOf(localLntoken);
					for (i3 = i2 - 1; i3 >= 0; --i3) {
						localParen = (Paren)((Vector)localObject3).elementAt(i3);
						if (localParen.token.length() != 0) localObject1 = localParen.token;
						if (localParen.after < 0) {
							localParen.after = i1;
							if (localParen.token.length() == 0) localParen.token = ((String)localObject1);
							((Vector)localObject3).setElementAt(localParen, i3);
							break;
						}
					}
				}
			}
			if (i > 0) {
				print(paramObject, "\n// JFront Error: The following statement has unbalenced Paren'()'s \n");
			}

			i4 = 99;
			localObject1 = " ";
			localObject2 = " ";
			int i5 = 0;
			int i6 = 0;
			i2 = 0;
			localEnumeration = paramVector.elements();
			k = 0;
			if (i == 0) {
				while (localEnumeration.hasMoreElements()) {
					localLntoken = (Lntoken)localEnumeration.nextElement();
					if (localLntoken.token.equals("(")) {
						++i;
						++i2;
					}
					if (localLntoken.token.equals(")")) --i;
					if ((k != 0) && 
						(localLntoken.type == -5)) {
						String str2 = (String)paramHashtable.get(str1);
						localObject1 = str2 + ":" + localLntoken.token;
						if (this.class_ops.containsKey(localObject1)) {
							int i7 = paramOpers.priority(localLntoken.token);

							if ((i > i5) || (
								(i == i5) && (i7 < i4)))
							{
								i4 = i7;
								i5 = i;
								i6 = paramVector.indexOf(localLntoken);
								localObject2 = localObject1;
								j = 0;
							}
						}

					}

					k = 0;
					str1 = "";

					if (localLntoken.type == -3) {
						if (!paramHashtable.containsKey(localLntoken.token))
							continue;
						k = 1;
						str1 = localLntoken.token;
					}
					else if (localLntoken.token.equals(")")) {
						localParen = (Paren)((Vector)localObject3).elementAt(i2 - 1);
						if (!paramHashtable.containsKey(localParen.token))
							continue;
						k = 1;
						str1 = localParen.token;
					}

				}

				if (j != 0)
					continue;
				localObject1 = localObject2;
				String str2 = (String)this.class_ops.get(localObject1);

				i1 = i6 + 2;
				l = i6 - 1;
				if (paramVector.size() > i6 + 1) {
					localLntoken = (Lntoken)paramVector.elementAt(i6 + 1);

					if (localLntoken.token.equals("("))
					{
						localParen = (Paren)((Vector)localObject3).elementAt(i2 - 1);
						i1 = localParen.after;
					}

					localLntoken = (Lntoken)paramVector.elementAt(i6 - 1);

					if (localLntoken.token.equals(")"))
					{
						for (i3 = 0; i3 < i2 - 1; --i3) {
							localParen = (Paren)((Vector)localObject3).elementAt(i3);
							if (localParen.after == i6 - 1) {
								l = localParen.before;
								break;
							}
						}

					}

				}

				paramVector.insertElementAt(new Lntoken(-6, ")"), i1);
				paramVector.insertElementAt(new Lntoken(-6, ")"), i1);
				paramVector.insertElementAt(new Lntoken(-6, "("), i6 + 1);
				paramVector.setElementAt(new Lntoken(-5, str2), i6);
				paramVector.insertElementAt(new Lntoken(-6, "."), i6);
				paramVector.insertElementAt(new Lntoken(-6, "("), l);
			}

		}

		localEnumeration = paramVector.elements();

		while (localEnumeration.hasMoreElements()) {
			localObject3 = (Lntoken)localEnumeration.nextElement();
			if (((Lntoken)localObject3).token.equals("{")) bracelev += 1;
			if (((Lntoken)localObject3).token.equals("}")) bracelev -= 1;

			print(paramObject, ((Lntoken)localObject3).token);
			if (((Lntoken)localObject3).token.substring(((Lntoken)localObject3).token.length() - 1).equals("\n"))
				for (i4 = 0; i4 < bracelev; ++i4) print(paramObject, " ");
		}
	}
}