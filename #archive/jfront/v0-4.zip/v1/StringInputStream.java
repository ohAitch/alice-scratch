package jfront;

import java.io.DataInput;
import java.io.InputStream;

public class StringInputStream extends InputStream
	implements DataInput
{
	String ins;
	int ptr;

	public StringInputStream(String paramString)
	{
		this.ins = paramString;
		this.ptr = 0;
	}

	public int read()
	{
		int i = -1;
		if (this.ptr < this.ins.length()) i = this.ins.charAt(this.ptr);
		this.ptr += 1;
		return i;
	}
	public void readFully(byte[] paramArrayOfByte) {
	}
	public void readFully(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {	}

	public int skipBytes(int paramInt) {return paramInt;} 
	public boolean readBoolean() {return false;} 
	public byte readByte() {return 0;} 
	public int readUnsignedByte() {return 0;} 
	public short readShort() {return 0;} 
	public int readUnsignedShort() {return 0;} 
	public char readChar() {return '\000';} 
	public int readInt() {return 0;} 
	public long readLong() {return 0L;} 
	public float readFloat() {return 0.0F;} 
	public double readDouble() {return 0.0D;} 
	public String readLine() {return "";} 
	public String readUTF() {return "";}

}