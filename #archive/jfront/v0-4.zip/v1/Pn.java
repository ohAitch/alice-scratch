package jfront;

public class Pn
{
	int level;
	String name;

	Pn(int paramInt, String paramString)
	{
		this.level = paramInt;
		this.name = paramString;
	}

	Pn() {
		this.level = 0;
		this.name = "";
	}
}