package jfront;

public class Opdef
{
	String op;
	String classname;
	String innername;
	String oPname;
}