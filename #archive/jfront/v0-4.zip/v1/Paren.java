package jfront;

public class Paren
{
	int before;
	int after;
	String token;
	int level;

	Paren(int paramInt1, int paramInt2)
	{
		this.before = paramInt1;
		this.after = 0;
		this.token = "";
		this.level = paramInt2;
	}

	Paren(int paramInt1, int paramInt2, String paramString, int paramInt3) {
		this.before = paramInt1;
		this.after = paramInt2;
		this.token = paramString;
		this.level = paramInt3;
	}
}