package jfront;

import java.io.IOException;
import java.io.InputStream;

public class StreamToken
{
	private InputStream input;
	private char[] buf = new char[20];
	private int peekc;
	private boolean pushedBack;
	private boolean forceLower;
	private int LINENO = 1;
	private String opstr = "";
	private Opers optbl = new Opers();

	private boolean eolIsSignificantP = false;
	private boolean slashSlashCommentsP = false;
	private boolean slashStarCommentsP = false;
	private boolean commentAsAlphaP = false;
	private boolean parseOps = false;

	private byte[] ctype = new byte[256];
	private static final byte CT_WHITESPACE = 1;
	private static final byte CT_DIGIT = 2;
	private static final byte CT_ALPHA = 4;
	private static final byte CT_QUOTE = 8;
	private static final byte CT_COMMENT = 16;
	public int ttype = -6;
	public static final int TT_EOF = -1;
	public static final int TT_EOL = 10;
	public static final int TT_NUMBER = -2;
	public static final int TT_WORD = -3;
	public static final int TT_COMMENT = -4;
	public static final int TT_OPER = -5;
	public static final int TT_NOTHING = -6;
	public String sval;
	public double nval;
	private boolean iscomment;

	private StreamToken()
	{
		wordChars(97, 122);
		wordChars(65, 90);
		wordChars(160, 255);
		whitespaceChars(0, 32);
		commentChar(47);
		quoteChar(34);
		quoteChar(39);

		this.iscomment = false;
		this.ttype = -6;
	}

	/** @deprecated */
	public StreamToken(InputStream paramInputStream)
	{
		this.input = paramInputStream;
	}

	public void resetSyntax()
	{
		for (int i = this.ctype.length; --i >= 0; )
			this.ctype[i] = 0;
	}

	public void wordChars(int paramInt1, int paramInt2)
	{
		if (paramInt1 < 0)
			paramInt1 = 0;
		if (paramInt2 >= this.ctype.length)
			paramInt2 = this.ctype.length - 1;
		while (paramInt1 <= paramInt2)
		{
			int tmp34_31 = (paramInt1++);
			byte[] tmp34_27 = this.ctype; tmp34_27[tmp34_31] = (byte)(tmp34_27[tmp34_31] | 0x4);
		}
	}

	public void wordChar(int paramInt) {
		if ((paramInt >= 0) && (paramInt < this.ctype.length))
		{
			int tmp18_17 = paramInt;
			byte[] tmp18_14 = this.ctype; tmp18_14[tmp18_17] = (byte)(tmp18_14[tmp18_17] | 0x4);
		}
	}

	public void whitespaceChars(int paramInt1, int paramInt2)
	{
		if (paramInt1 < 0)
			paramInt1 = 0;
		if (paramInt2 >= this.ctype.length)
			paramInt2 = this.ctype.length - 1;
		while (paramInt1 <= paramInt2)
			this.ctype[(paramInt1++)] = 1;
	}

	public void ordinaryChars(int paramInt1, int paramInt2)
	{
		if (paramInt1 < 0)
			paramInt1 = 0;
		if (paramInt2 >= this.ctype.length)
			paramInt2 = this.ctype.length - 1;
		while (paramInt1 <= paramInt2)
			this.ctype[(paramInt1++)] = 0;
	}

	public void ordinaryChar(int paramInt)
	{
		if ((paramInt >= 0) && (paramInt < this.ctype.length))
			this.ctype[paramInt] = 0;
	}

	public void commentChar(int paramInt)
	{
		if ((paramInt >= 0) && (paramInt < this.ctype.length))
			this.ctype[paramInt] = 16;
	}

	public void quoteChar(int paramInt)
	{
		if ((paramInt >= 0) && (paramInt < this.ctype.length))
			this.ctype[paramInt] = 8;
	}

	public void parseNumbers()
	{
		for (int i = 48; i <= 57; ++i)
		{
			int tmp11_10 = i;
			byte[] tmp11_7 = this.ctype; tmp11_7[tmp11_10] = (byte)(tmp11_7[tmp11_10] | 0x2);
		}
		byte[] tmp32_27 = this.ctype; tmp32_27[46] = (byte)(tmp32_27[46] | 0x2);
		byte[] tmp44_39 = this.ctype; tmp44_39[45] = (byte)(tmp44_39[45] | 0x2);
	}

	public void eolIsSignificant(boolean paramBoolean)
	{
		this.eolIsSignificantP = paramBoolean;
	}

	public void slashStarComments(boolean paramBoolean)
	{
		this.slashStarCommentsP = paramBoolean;
	}

	public void slashSlashComments(boolean paramBoolean)
	{
		this.slashSlashCommentsP = paramBoolean;
	}

	public void commentAsAlpha(boolean paramBoolean)
	{
		if (paramBoolean) this.ctype[47] = 16;
		this.commentAsAlphaP = paramBoolean;
	}

	public void lowerCaseMode(boolean paramBoolean)
	{
		this.forceLower = paramBoolean;
	}

	public void parseOperators(boolean paramBoolean) {
		this.parseOps = paramBoolean;
	}

	private int read()
		throws IOException
	{
		if (this.input != null)
		{
			return this.input.read();
		}

		throw new IOException("IllegalStateException");
	}

	public int nextToken()
		throws IOException
	{
		if (this.pushedBack) {
			this.pushedBack = false;
			return this.ttype;
		}
		byte[] arrayOfByte = this.ctype;

		this.sval = null;
		this.opstr = "";
		int i;
		if (this.ttype == -6) {
			i = read();
			if (i >= 0)
				this.ttype = i;
		} else {
			i = this.peekc;
		}

		if (i < 0) {
			return this.ttype = -1;
		}
		int j = (i < 256) ? arrayOfByte[i] : 4;

		while ((j & 0x1) != 0) {
			if (i == 13) {
				this.LINENO += 1;
				i = read();
				if (i == 10)
					i = read();
				if (this.eolIsSignificantP) {
					this.peekc = i;
					return this.ttype = 10;
				}
			} else {
				if (i == 10) {
					this.LINENO += 1;
					if (this.eolIsSignificantP) {
						this.peekc = read();
						return this.ttype = 10;
					}
				}
				i = read();
			}
			if (i < 0)
				return this.ttype = -1;
			j = (i < 256) ? arrayOfByte[i] : 4;
		}
		int k;
		if (((this.commentAsAlphaP) && ((j & 0x10) != 0)) || (this.iscomment)) {
			k = 1;
			this.buf[0] = (char)i;

			this.peekc = read();
			if ((this.iscomment) || (this.peekc == 42) || (this.peekc == 47))
			{
				i = this.peekc;
				while ((i != 10) && (i != 13) && (i >= 0))
				{
					if ((k == 1) && (i == 42)) this.iscomment = true;

					if (k >= this.buf.length) {
						char[] arrayOfChar1 = new char[this.buf.length * 2];
						System.arraycopy(this.buf, 0, arrayOfChar1, 0, this.buf.length);
						this.buf = arrayOfChar1;
					}
					this.buf[(k++)] = (char)i;

					if ((this.iscomment) && ((char)i == '/') && (this.buf[(k - 2)] == '*'))
					{
						this.iscomment = false;
						i = read();
						break;
					}
					i = read();
				}
				this.sval = String.copyValueOf(this.buf, 0, k);
				this.peekc = i;
				return this.ttype = -4;
			}

		}

		if ((j & 0x2) != 0) {
			k = 0;
			if (i == 45) {
				i = read();
				if ((i != 46) && (((i < 48) || (i > 57)))) {
					this.peekc = i;
					return this.ttype = 45;
				}
				k = 1;
			}
			double d1 = 0.0D;
			int i1 = 0;
			int i2 = 0;
			while (true) {
				if ((i == 46) && (i2 == 0)) {
					i2 = 1;} else {
					if ((i < 48) || (i > 57)) break;
					d1 = d1 * 10.0D + (i - 48);
					i1 += i2;
				}

				i = read();
			}
			this.peekc = i;
			if (i1 != 0) {
				double d2 = 10.0D;
				--i1;
				while (i1 > 0) {
					d2 *= 10.0D;
					--i1;
				}

				d1 /= d2;
			}
			this.nval = ((k != 0) ? -d1 : d1);
			return this.ttype = -2;
		}
		char[] arrayOfChar2;
		if ((j & 0x4) != 0) {
			k = 0;
			do {
				if (k >= this.buf.length) {
					arrayOfChar2 = new char[this.buf.length * 2];
					System.arraycopy(this.buf, 0, arrayOfChar2, 0, this.buf.length);
					this.buf = arrayOfChar2;
				}
				this.buf[(k++)] = (char)i;
				i = read();
				j = (i < 256) ? arrayOfByte[i] : (i < 0) ? 1 : 4;
			}while ((j & 0x6) != 0);
			this.peekc = i;
			this.sval = String.copyValueOf(this.buf, 0, k);
			if (this.forceLower)
				this.sval = this.sval.toLowerCase();
			return this.ttype = -3;
		}

		if ((j & 0x8) != 0) {
			this.ttype = i;
			k = 0;

			this.peekc = read();
			while ((this.peekc >= 0) && (this.peekc != this.ttype) && (this.peekc != 10) && (this.peekc != 13)) {
				i = this.peekc;
				this.peekc = read();

				if (k >= this.buf.length) {
					arrayOfChar2 = new char[this.buf.length * 2];
					System.arraycopy(this.buf, 0, arrayOfChar2, 0, this.buf.length);
					this.buf = arrayOfChar2;
				}
				this.buf[(k++)] = (char)i;
			}
			if (this.peekc == this.ttype)
				this.peekc = read();
			this.sval = String.copyValueOf(this.buf, 0, k);
			return this.ttype;
		}

		if ((i == 47) && (((this.slashSlashCommentsP) || (this.slashStarCommentsP)))) {
			i = read();
			if ((i == 42) && (this.slashStarCommentsP)) {
				k = 0;
				while (((i = read()) != 47) || (k != 42))
				{
					if (i == 13) {
						this.LINENO += 1;
						i = read();
						if (i == 10) {
							i = read();
						}
					}
					else if (i == 10)
					{
						this.LINENO += 1;
						i = read();
					}

					if (i < 0)
						return this.ttype = -1;
					k = i;
				}
				this.peekc = read();
				return nextToken();
			}
			if ((i == 47) && (this.slashSlashCommentsP)) {
				while (((i = read()) != 10) && (i != 13) && (i >= 0));
				this.peekc = i;
				return nextToken();
			}
			this.peekc = i;
			return this.ttype = 47;
		}

		if (this.parseOps)
		{
			if ((this.commentAsAlphaP) && ((char)i != '/')) this.peekc = read();

			this.opstr = String.valueOf((char)i);

			boolean bool = this.optbl.look(this.opstr);
			if (!bool) {
				this.ttype = i;
				i = this.peekc;
				return this.ttype;
			}

			for (int l = 0; l < 3; ++l) {
				this.opstr += String.valueOf((char)this.peekc);
				bool = this.optbl.look(this.opstr);
				if (!bool)
				{
					this.sval = this.opstr.substring(0, this.opstr.length() - 1);

					return this.ttype = -5;
				}
				this.peekc = read();
			}
			this.sval = this.opstr;

			return this.ttype = -5;
		}

		return this.ttype = i;
	}

	public void pushBack()
	{
		if (this.ttype != -6)
			this.pushedBack = true;
	}

	public int lineno()
	{
		return this.LINENO;
	}

	public String toString()
	{
		String str;
		switch (this.ttype)
		{
		case -1:
			str = "EOF";
			break;
		case 10:
			str = "EOL";
			break;
		case -3:
			str = this.sval;
			break;
		case -2:
			str = "n=" + this.nval;
			break;
		case -6:
			str = "NOTHING";
			break;
		default:
			char[] arrayOfChar = new char[3];
			arrayOfChar[2] = 39; arrayOfChar[0] = 39;
			arrayOfChar[1] = (char)this.ttype;
			str = new String(arrayOfChar);
		}

		return "Token[" + str + "], line " + this.LINENO;
	}
}