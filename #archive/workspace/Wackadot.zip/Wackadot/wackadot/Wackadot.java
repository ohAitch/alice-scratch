package wackadot;

import java.awt.Color;
import java.awt.geom.*;
import fang.*;

public class Wackadot extends GameLoop
{	
	private StringSprite scoreSprite;
	private int score;
    private Sprite dot;
    private Sprite redDot;
    private Sprite blueDot;
    private int timeLeft;
    private StringSprite timerSprite;
    
    private void repositionRandomly(Sprite sprite)
    {
        sprite.setLocation(
                random.nextDouble(),
                random.nextDouble());
    }
    
	public void advanceFrame(double timePassed)
	{
	    if(timeLeft>0)
	    {
	        Point2D.Double mouse=
	            getPlayer().getMouse().getLocation();
	        dot.setLocation(mouse);
	        handleCollisions();
	    }
	}
     
    public void startGame()
    {
        score=0;
        timeLeft=10;
        makeSprites();
        addSprites();
        scheduleRelative(new TimeUpdater(), 1);
        setHelp("resources/WackadotHelp.html");
    }
    
    class TimeUpdater implements Alarm
    {
       public void alarm()
       {
            timeLeft--;
            updateTimer();
            if(timeLeft>0)
            {
                scheduleRelative(this, 1);
            }
        }
    }
    
    private void makeSprites()
    {
        Ellipse2D.Double circle=
            new Ellipse2D.Double(0, 0, 1, 1);

        dot=new Sprite(circle);
        dot.setScale(0.1);
        dot.setLocation(0.5, 0.5);
        dot.setColor(Color.red);
        
        redDot=new Sprite(circle);
        redDot.setScale(0.1);
        redDot.setLocation(
               random.nextDouble(),
               random.nextDouble());
        redDot.setColor(Color.RED);

        blueDot=new Sprite(circle);
        blueDot.setScale(0.1);
        blueDot.setLocation(
               random.nextDouble(),
               random.nextDouble());
        blueDot.setColor(Color.BLUE);
        
        scoreSprite=new StringSprite("Score: "+score);
        scoreSprite.setHeight(0.1);
        scoreSprite.rightJustify();
        scoreSprite.topJustify();
        scoreSprite.setLocation(1, 0);
        
        scoreSprite=new StringSprite("Score: "+score);
        scoreSprite.setHeight(0.1);
        scoreSprite.rightJustify();
        scoreSprite.topJustify();
        scoreSprite.setLocation(1, 0);
        
        timerSprite=new StringSprite("Timer: "+timeLeft);
        timerSprite.leftJustify();
        timerSprite.topJustify();
        timerSprite.setHeight(0.1);
        timerSprite.setLocation(0, 0);
    }
    
    private void addSprites()
    {
        canvas.addSprite(dot);
        canvas.addSprite(redDot);
        canvas.addSprite(blueDot);
        canvas.addSprite(scoreSprite);
        canvas.addSprite(timerSprite);
    }
    
    private void updateTimer()
    {
        timerSprite.setText("Timer: "+timeLeft);
    }
    
    private void updateScore()
    {
        scoreSprite.setText("Score: "+score);
    }
    
    private void handleCollisions()
    {
        if(dot.intersects(blueDot) ||
        		dot.intersects(redDot))
        {
            long seed=(long)(1000*getTime());
            random.setSeed(seed);
        }
        if(dot.intersects(blueDot))
        {
            repositionRandomly(blueDot);
            if(dot.getColor().equals(Color.BLUE))
            {
                dot.setColor(Color.RED);
                score++;
            }
            else
            {
                score--;
            }
            updateScore();
        }
        if(dot.intersects(redDot))
        {
            repositionRandomly(redDot);
            if(dot.getColor().equals(Color.RED))
            {
                dot.setColor(Color.BLUE);
                score++;
            }
            else
            {
                score--;
            }
            updateScore();
        }
    }
    
    public static void main(String[] argv)
    {
        Wackadot dot=new Wackadot();
        dot.runAsApplication();
    }
}